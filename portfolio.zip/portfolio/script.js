// Shows/hides the tab navigation on small screens where it doesn't fit in one row.

const menuToggle = document.getElementById("menuToggle");
const tabsNav = document.getElementById("tabsNav");

menuToggle.addEventListener("click", () => {
  tabsNav.classList.toggle("open");
});

// Close the menu after picking a tab (nicer on mobile)
const tabLinks = document.querySelectorAll(".tab");
tabLinks.forEach((link) => {
  link.addEventListener("click", () => {
    tabsNav.classList.remove("open");
  });
});
